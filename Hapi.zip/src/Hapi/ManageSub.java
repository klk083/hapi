package Hapi;

import javax.swing.*;

/**
 * Created by klk94 on 13.03.2016.
 */
public class ManageSub {
    private JList list1;
    private JButton deleteSubsrciptionButton;
    private JButton editSubscriptionButton;
    private JButton backButton;
    private JButton addSubscriptionButton;
}
