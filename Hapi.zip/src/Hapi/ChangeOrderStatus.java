package Hapi;

import javax.swing.*;

/**
 * Created by klk94 on 11.03.2016.
 */
public class ChangeOrderStatus {
    private JList list1;
    private JButton deliveredButton;
    private JButton backButton;
}
