package Hapi;

import javax.swing.*;

/**
 * Created by klk94 on 13.03.2016.
 */
public class AddSub {
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JButton cancelButton;
    private JButton OKButton;
    private JList list1;
    private JList list2;
    private JButton addButton;
    private JButton removeButton;
}
