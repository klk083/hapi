package Hapi;

import javax.swing.*;

/**
 * Created by klk94 on 11.03.2016.
 */
public class CreateOrder {
    private JList list1;
    private JTextField textField1;
    private JButton createMenyOrderButton;
    private JButton backButton;
    private JButton searchButton;
    private JButton createNewCustomerButton;
    private JButton createSubOrderButton;
}
