package Hapi;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by klk94 on 16.03.2016.
 */
public class ManageCustomers {
    private JList list1;
    private JTextField textField1;
    private JButton searchButton;
    private JButton editButton;
    private JButton addButton;
    private JButton cancelButton;
    private JButton deleteButton;

    public ManageCustomers() {
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }
}
