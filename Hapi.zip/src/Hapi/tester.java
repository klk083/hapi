package Hapi;

/**
 * Created by klk94 on 16.03.2016.
 */
public class tester {
    public static void main(String[] args) {
        LoggIn tester = new LoggIn();
    }
}
