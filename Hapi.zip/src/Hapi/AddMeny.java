package Hapi;

import javax.swing.*;

/**
 * Created by klk94 on 13.03.2016.
 */
public class AddMeny {
    private JTextField textField1;
    private JTextField textField2;
    private JList list1;
    private JButton backButton;
    private JButton okButton;
    private JList list2;
    private JButton addButton;
    private JButton removeButton;
}
