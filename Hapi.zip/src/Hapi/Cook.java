package Hapi;

import javax.swing.*;

/**
 * Created by klk94 on 16.03.2016.
 */
public class Cook {
    private JButton manageTablesButton;
    private JCheckBox checkBox1;
    private JButton lookAtOrdersButton;
    private JCheckBox checkBox2;
}
