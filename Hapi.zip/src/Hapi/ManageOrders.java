package Hapi;

import javax.swing.*;

/**
 * Created by klk94 on 11.03.2016.
 */
public class ManageOrders {
    private JButton createNewOrderButton;
    private JList list1;
    private JButton changeOrderButton;
    private JButton backButton;


}
