package Hapi;

import javax.swing.*;

/**
 * Created by klk94 on 13.03.2016.
 */
public class EditSub {
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JButton okButton;
    private JButton cancelButton;
}
