package Hapi;

import javax.swing.*;

/**
 * Created by klk94 on 16.03.2016.
 */
public class Driver {
    private JCheckBox checkBox1;
    private JButton changeOrderStatusButton;
    private JButton signOutButton;
}
