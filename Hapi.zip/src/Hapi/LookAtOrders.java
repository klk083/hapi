package Hapi;

import javax.swing.*;

/**
 * Created by klk94 on 16.03.2016.
 */
public class LookAtOrders {
    private JList list1;
    private JTextField textField1;
    private JTextField textField2;
    private JButton searchButton;
    private JButton backButton;
}
